#include <stdio.h>

int main() {
    FILE *file;
    int data[5];
    int size = sizeof(data) / sizeof(data[0]);
    file = fopen("data.bin", "rb");
    if (file == NULL) {
        printf("Error opening the file.\n");
        return 1;
    }
    fread(data, sizeof(int), size, file);
    fclose(file);
    printf("Binary data read from the file:\n");
    for (int i = 0; i < size; i++) {
        printf("%d ", data[i]);
    }
    printf("\n");

    return 0;
}

