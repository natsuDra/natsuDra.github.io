#include <stdio.h>
#include <stdbool.h>
bool isSorted(int arr[], int n) {
    for (int i = 1; i < n; i++) {
        if (arr[i] < arr[i - 1]) {
            return false;
        }
    }
    return true;
}

int binarySearch(int arr[], int left, int right, int target) {
    while (left <= right) {
        int mid = left + (right - left) / 2;

        if (arr[mid] == target) {
            return mid; 
        } else if (arr[mid] < target) {
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }
    return -1; 
}

int main() {
    int n, target;
    printf("Enter the number of elements in the sorted array: ");
    if (scanf("%d", &n) != 1 || n <= 0) {
        printf("Invalid input. Please enter a valid positive integer for the number of elements.\n");
        return 1;
    }

    int arr[n];
    printf("Enter %d sorted elements:\n", n);
    for (int i = 0; i < n; i++) {
        if (scanf("%d", &arr[i]) != 1) {
            printf("Invalid input. Please enter a valid integer for the array element.\n");
            return 1;
        }
    }

    if (!isSorted(arr, n)) {
        printf("The array is not sorted in ascending order. Binary search requires a sorted array.\n");
        return 1;
    }

    printf("Enter the number to search: ");
    if (scanf("%d", &target) != 1) {
        printf("Invalid input. Please enter a valid integer for the target number.\n");
        return 1;
    }

    int index = binarySearch(arr, 0, n - 1, target);
    if (index != -1) {
        printf("%d found at index %d\n", target, index);
    } else {
        printf("%d not found in the array.\n", target);
    }

    return 0;
}

