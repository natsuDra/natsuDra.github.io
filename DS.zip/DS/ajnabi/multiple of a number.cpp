#include <stdio.h>

int main() {
    int number, limit;
    printf("Enter a number: ");
    scanf("%d", &number);
    printf("Enter the limit: ");
    scanf("%d", &limit);
    printf("Multiples of %d up to %d:\n ", number, limit);
    for (int i = 1; i <= limit; i++) {
        printf("%d\n ", number * i);
    }
    printf("\n");

    return 0;
}

