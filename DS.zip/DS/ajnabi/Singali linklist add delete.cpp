#include <stdio.h>
#include <stdlib.h>
struct Node {
    int data;
    struct Node* next;
};
struct Node* createNode(int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    if (newNode) {
        newNode->data = data;
        newNode->next = NULL;
    }
    return newNode;
}
void insertAtBeginning(struct Node** head, int data) {
    struct Node* newNode = createNode(data);
    if (newNode) {
        newNode->next = *head;
        *head = newNode;
    }
}
void deleteNode(struct Node** head, int key) {
    struct Node* current = *head;
    struct Node* prev = NULL;
    if (current != NULL && current->data == key) {
        *head = current->next;
        free(current);
        return;
    }
    while (current != NULL && current->data != key) {
        prev = current;
        current = current->next;
    }
    if (current == NULL) {
        printf("Element %d not found in the linked list.\n", key);
        return;
    }
    prev->next = current->next;
    free(current);
}
void displayList(struct Node* head) {
    printf("Linked List: ");
    while (head) {
        printf("%d -> ", head->data);
        head = head->next;
    }
    printf("NULL\n");
}
void deleteList(struct Node** head) {
    struct Node* current = *head;
    struct Node* nextNode;

    while (current != NULL) {
        nextNode = current->next;
        free(current);
        current = nextNode;
    }

    *head = NULL;
}
int main() {
    struct Node* head = NULL;
    int input, choice;

    printf("Linked List Operations\n");
    printf("1. Insert an element\n");
    printf("2. Delete an element\n");
    printf("3. Display the linked list\n");
    printf("4. Exit\n");

    while (1) {
        printf("Enter your choice (1/2/3/4): ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter the number to insert: ");
                scanf("%d", &input);
                insertAtBeginning(&head, input);
                break;
            case 2:
                if (head == NULL) {
                    printf("Linked list is empty. Cannot delete.\n");
                } else {
                    printf("Enter the number to delete: ");
                    scanf("%d", &input);
                    deleteNode(&head, input);
                }
                break;
            case 3:
                displayList(head);
                break;
            case 4:
                deleteList(&head);
                printf("Linked list deleted. Exiting.\n");
                return 0;
            default:
                printf("Invalid choice. Try again.\n");
                break;
        }
    }

    return 0;
}
