#include <stdio.h>
#include <stdlib.h>
#define MAX_SIZE 100

struct Stack {
    int data[MAX_SIZE];
    int top;
};
void initialize(struct Stack* stack) {
    stack->top = -1;
}
int isFull(struct Stack* stack) {
    return (stack->top == MAX_SIZE - 1);
}
int isEmpty(struct Stack* stack) {
    return (stack->top == -1);
}

void push(struct Stack* stack, int element) {
    if (isFull(stack)) {
        printf("Stack is full. Cannot push.\n");
        return;
    }
    stack->data[++stack->top] = element;
}
int pop(struct Stack* stack) {
    if (isEmpty(stack)) {
        printf("Stack is empty. Cannot pop.\n");
        return -1;
    }
    return stack->data[stack->top--];
}
void display(struct Stack* stack) {
    if (isEmpty(stack)) {
        printf("Stack is empty.\n");
        return;
    }
    printf("Stack: ");
    for (int i = 0; i <= stack->top; i++) {
        printf("%d ", stack->data[i]);
    }
    printf("\n");
}
int main() {
    struct Stack stack;
    initialize(&stack);
    int input, choice;
    printf("Stack Operations\n");
    printf("1. Push an element\n");
    printf("2. Pop an element\n");
    printf("3. Display the stack\n");
    printf("4. Exit\n");

    while (1) {
        printf("Enter your choice (1/2/3/4): ");
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                printf("Enter the number to push: ");
                scanf("%d", &input);
                push(&stack, input);
                break;
            case 2:
                if (isEmpty(&stack)) {
                    printf("Stack is empty. Cannot pop.\n");
                } else {
                    int poppedElement = pop(&stack);
                    printf("Popped element: %d\n", poppedElement);
                }
                break;
            case 3:
                display(&stack);
                break;
            case 4:
                printf("Exiting.\n");
                return 0;
            default:
                printf("Invalid choice. Try again.\n");
                break;
        }
    }

    return 0;
}

