#include <stdio.h>
#include <stdbool.h>
#define MAX_SIZE 10 

typedef struct {
    int arr[MAX_SIZE];
    int top1; 
    int top2; 
    int size1; 
    int size2; 
} MultiStack;
void initMultiStack(MultiStack* stack) {
    stack->top1 = -1;
    stack->top2 = MAX_SIZE;
    stack->size1 = 0;
    stack->size2 = 0;
}
void pushToStack1(MultiStack* stack, int data) {
    if (stack->top1 + 1 == stack->top2) {
        printf("Stack Overflow: Unable to push element to stack 1\n");
        return;
    }
    stack->top1++;
    stack->arr[stack->top1] = data;
    stack->size1++;
}
void pushToStack2(MultiStack* stack, int data) {
    if (stack->top1 + 1 == stack->top2) {
        printf("Stack Overflow: Unable to push element to stack 2\n");
        return;
    }
    stack->top2--;
    stack->arr[stack->top2] = data;
    stack->size2++;
}
int popFromStack1(MultiStack* stack) {
    if (stack->size1 == 0) {
        printf("Stack Underflow: Unable to pop element from stack 1\n");
        return -1;
    }
    int data = stack->arr[stack->top1];
    stack->top1--;
    stack->size1--;
    return data;
}
int popFromStack2(MultiStack* stack) {
    if (stack->size2 == 0) {
        printf("Stack Underflow: Unable to pop element from stack 2\n");
        return -1;
    }
    int data = stack->arr[stack->top2];
    stack->top2++;
    stack->size2--;
    return data;
}
bool isStack1Empty(MultiStack* stack) {
    return stack->size1 == 0;
}
bool isStack2Empty(MultiStack* stack) {
    return stack->size2 == 0;
}
int stack1Size(MultiStack* stack) {
    return stack->size1;
}
int stack2Size(MultiStack* stack) {
    return stack->size2;
}
int main() {
    MultiStack stack;
    initMultiStack(&stack);

    pushToStack1(&stack, 10);
    pushToStack1(&stack, 20);
    pushToStack1(&stack, 30);
    pushToStack1(&stack, 40);
    pushToStack1(&stack, 50);
    
    pushToStack2(&stack, 60);
    pushToStack2(&stack, 70);
    pushToStack2(&stack, 80);
    pushToStack2(&stack, 90);
    pushToStack2(&stack, 100);
    printf("Elements in Stack 1 before pop: ");
    for (int i = 0; i <= stack.top1; i++) {
        printf("%d ", stack.arr[i]);
    }
    printf("\n");
    printf("Elements in Stack 2 before pop: ");
    for (int i = MAX_SIZE - 1; i >= stack.top2; i--) {
        printf("%d ", stack.arr[i]);
    }
    printf("\n");
    printf("Stack 1 Size: %d\n", stack1Size(&stack));
    printf("Stack 2 Size: %d\n", stack2Size(&stack));
    printf("Pop from Stack 1: %d\n", popFromStack1(&stack));
    printf("Pop from Stack 2: %d\n", popFromStack2(&stack));
    return 0;
}

