#include <stdio.h>
#include <math.h>
#include <stdbool.h>

int countDigits(int num) {
    if (num == 0)
        return 0;
    return 1 + countDigits(num / 10);
}

int power(int base, int exponent) {
    if (exponent == 0)
        return 1;
    return base * power(base, exponent - 1);
}

int isArmstrong(int num, int numDigits) {
    if (num == 0)
        return 0;

    int digit = num % 10;
    return power(digit, numDigits) + isArmstrong(num / 10, numDigits);
}

int main() {
    int num;
    printf("Enter a positive integer: ");

    if (scanf("%d", &num) != 1 || num < 0) {
        printf("Invalid input. Please enter a positive integer.\n");
        return 1;
    }

    int numDigits = countDigits(num);
    int result = isArmstrong(num, numDigits);

    if (result == num)
        printf("%d is an Armstrong number.\n", num);
    else
        printf("%d is not an Armstrong number.\n", num);

    return 0;
}

