#include <stdio.h>

int main() {
    FILE *file;
    int data[] = {10, 20, 30, 40, 50};
    int size = sizeof(data) / sizeof(data[0]);
    file = fopen("data.bin", "wb");
    if (file == NULL) {
        printf("Error opening the file.\n");
        return 1;
    }
    fwrite(data, sizeof(int), size, file);
    fclose(file);
    printf("Binary data has been written to the file.\n");

    return 0;
}

