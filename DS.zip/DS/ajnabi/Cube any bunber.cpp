#include <stdio.h>
long long int cube(int n) {
    if (n == 0)
        return 0; 

    if (n == 1)
        return 1; 
    return n * n * n;
}

int main() {
    int num;
    printf("Enter a number: ");
    scanf("%d", &num);

    long long int result = cube(num);
    printf("Cube of %d is %lld\n", num, result);

    return 0;
}

