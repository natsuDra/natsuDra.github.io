#include <stdio.h>
int fibonacci(int n) {
    if (n <= 0)
        return -1; 

    if (n == 1)
        return 0; 

    if (n == 2)
        return 1; 

    return fibonacci(n - 1) + fibonacci(n - 2);
}

int main() {
    int n;
    printf("Enter the number to find fibonacci Series: ");
    scanf("%d", &n);

    if (n <= 0) {
        printf("Invalid input. Number of terms should be greater than 0.\n");
        return 1;
    }

    printf("Fibonacci series up to %d terms:\n", n);
    for (int i = 1; i <= n; i++) {
        printf("%d ", fibonacci(i));
    }
    printf("\n");

    return 0;
}

