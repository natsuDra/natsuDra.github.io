#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct Node {
    char data;
    unsigned frequency;
    struct Node *left, *right;
};
struct MinHeapNode {
    struct Node *data;
    struct MinHeapNode *next;
};
struct MinHeap {
    struct MinHeapNode *head;
};
struct Node* createNode(char data, unsigned frequency) {
    struct Node* temp = (struct Node*)malloc(sizeof(struct Node));
    temp->data = data;
    temp->frequency = frequency;
    temp->left = temp->right = NULL;
    return temp;
}
struct MinHeapNode* createMinHeapNode(struct Node* data) {
    struct MinHeapNode* temp = (struct MinHeapNode*)malloc(sizeof(struct MinHeapNode));
    temp->data = data;
    temp->next = NULL;
    return temp;
}
struct MinHeap* createMinHeap() {
    struct MinHeap* minHeap = (struct MinHeap*)malloc(sizeof(struct MinHeap));
    minHeap->head = NULL;
    return minHeap;
}
struct MinHeapNode* mergeNodes(struct MinHeapNode* a, struct MinHeapNode* b) {
    struct MinHeapNode* temp = createMinHeapNode(createNode('$', a->data->frequency + b->data->frequency));
    temp->data->left = a->data;
    temp->data->right = b->data;
    return temp;
}
void insertMinHeap(struct MinHeap* minHeap, struct MinHeapNode* node) {
    if (minHeap->head == NULL || node->data->frequency < minHeap->head->data->frequency) {
        node->next = minHeap->head;
        minHeap->head = node;
    } else {
        struct MinHeapNode* current = minHeap->head;
        while (current->next != NULL && current->next->data->frequency < node->data->frequency) {
            current = current->next;
        }
        node->next = current->next;
        current->next = node;
    }
}
struct Node* buildHuffmanTree(char data[], unsigned frequency[], int size) {
    struct MinHeap* minHeap = createMinHeap();

    for (int i = 0; i < size; i++) {
        insertMinHeap(minHeap, createMinHeapNode(createNode(data[i], frequency[i])));
    }

    while (minHeap->head->next != NULL) {
        struct MinHeapNode *a = minHeap->head;
        minHeap->head = minHeap->head->next;

        struct MinHeapNode *b = minHeap->head;
        minHeap->head = minHeap->head->next;

        struct MinHeapNode *temp = mergeNodes(a, b);
        insertMinHeap(minHeap, temp);
    }

    return minHeap->head->data;
}
void printCodes(struct Node* root, int arr[], int top) {
    if (root->left) {
        arr[top] = 0;
        printCodes(root->left, arr, top + 1);
    }

    if (root->right) {
        arr[top] = 1;
        printCodes(root->right, arr, top + 1);
    }

    if (!root->left && !root->right) {
        printf("%c: ", root->data);
        for (int i = 0; i < top; i++) {
            printf("%d", arr[i]);
        }
        printf("\n");
    }
}
void huffmanCodes(char data[], unsigned frequency[], int size) {
    struct Node* root = buildHuffmanTree(data, frequency, size);

    int arr[100], top = 0;
    printf("Huffman Codes:\n");
    printCodes(root, arr, top);
}

int main() {
    char data[] = { 'a', 'b', 'c', 'd', 'e', 'f' };
    unsigned frequency[] = { 5, 9, 12, 13, 16, 45 };
    int size = sizeof(data) / sizeof(data[0]);

    huffmanCodes(data, frequency, size);

    return 0;
}

