#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int value;
    int weight;
} Item;
int compareItems(const void *a, const void *b) {
    double ratioA = ((Item *)a)->value / (double)((Item *)a)->weight;
    double ratioB = ((Item *)b)->value / (double)((Item *)b)->weight;

    if (ratioA < ratioB) return 1;
    else if (ratioA > ratioB) return -1;
    else return 0;
}
void knapsackGreedy(Item items[], int n, int capacity) {
    qsort(items, n, sizeof(Item), compareItems);

    int *selected = (int *)malloc(n * sizeof(int));
    int currentWeight = 0;
    double totalValue = 0.0;

    for (int i = 0; i < n; i++) {
        selected[i] = 0;
    }

    for (int i = 0; i < n; i++) {
        if (currentWeight + items[i].weight <= capacity) {
            selected[i] = 1;
            currentWeight += items[i].weight;
            totalValue += items[i].value;
        }
    }

    printf("Selected items:\n");
    for (int i = 0; i < n; i++) {
        if (selected[i]) {
            printf("Item %d - Value: %d, Weight: %d\n", i + 1, items[i].value, items[i].weight);
        }
    }

    printf("Total value: %.2lf\n", totalValue);

    free(selected);
}

int main() {
    int n, capacity;

    printf("Enter the number of items: ");
    scanf("%d", &n);

    Item *items = (Item *)malloc(n * sizeof(Item));

    printf("Enter the value and weight of each item:\n");
    for (int i = 0; i < n; i++) {
        printf("Item %d: ", i + 1);
        scanf("%d %d", &items[i].value, &items[i].weight);
    }

    printf("Enter the capacity of the knapsack: ");
    scanf("%d", &capacity);

    knapsackGreedy(items, n, capacity);

    free(items);

    return 0;
}

